export class RegistroPdf{

    constructor(){}

    idUsuario:number;
    folio:String;
    fechaPago:String;
    monto:number;
    pago:number;
    cambio:number;
}