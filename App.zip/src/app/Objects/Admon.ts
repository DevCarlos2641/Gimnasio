export class Admon{
    idAdmon:number;
    user:String;
    password:String;
}