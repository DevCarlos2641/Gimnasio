export class Usuario{

    idUsuario:number;
    nombres:String = "";            //In Table
    apellidos:String = "";          //In Table
    telefono:number;           //In Table
    sexo:String = "";
    edad:number;
    email:String = "";              //In Table
    enfermedad:String;
    nip:number;

    constructor(){}
}
