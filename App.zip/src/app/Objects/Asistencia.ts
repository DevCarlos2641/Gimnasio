export class Asistencia{
  constructor(){}
  fecha:String;
  hora:String;
  idUsuario:number;
  servicio:String;
}
