
export class Membresia{

    constructor(){}

    idUsuario:number;
    fechaPago:String;
    fechaExpiracion:String;
    monto:number = 250;
    estudiante:boolean = false;

}