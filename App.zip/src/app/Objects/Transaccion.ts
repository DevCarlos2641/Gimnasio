export class Transaccion{
    constructor(){}

    idUsuario:number;
    fecha:String;
    monto:number;
    tipo:String;
}