import { TestBed } from '@angular/core/testing';
import { AppComponent } from './app.component';

describe('AppComponent', () => {
  let component: AppComponent;

  beforeEach(() => TestBed.configureTestingModule({
    declarations: [AppComponent]

  }));

  component = TestBed.createComponent(AppComponent).componentInstance;

  it('', (done:DoneFn)=>{
    component.checkMembresias(1);
    done();
  })

});
