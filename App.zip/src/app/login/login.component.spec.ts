import { ComponentFixture, TestBed } from '@angular/core/testing';
import { LoginComponent } from './login.component';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { ServicioDataMYSQLService } from '../Services/servicio-data-mysql.service';
import { FormsModule, NgForm } from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

describe('LoginComponent', () => {
  let service: ServicioDataMYSQLService;
  let component: LoginComponent;

  beforeEach(async () => {

    await TestBed.configureTestingModule({
      imports:[
        HttpClientTestingModule,
        FormsModule, BrowserAnimationsModule],
      declarations: [LoginComponent],
      providers:[ServicioDataMYSQLService]
    }).compileComponents;

    component = TestBed.createComponent(LoginComponent).componentInstance;

  });

  it('should Login', () => {

    const testForm = <NgForm>{
      value: {
          userL: "admin",
          passwordL: "admin"
      }
    };
    const re = [{0:"error"}];
    component.login(testForm);

  })
});
